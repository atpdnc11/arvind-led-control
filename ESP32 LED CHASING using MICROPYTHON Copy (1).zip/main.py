import time
from machine import Pin

led_pins = [25, 26, 27, 14, 12, 13, 15, 2, 4, 18]

# Set up LED pins as output
leds = [Pin(pin_num, Pin.OUT) for pin_num in led_pins]

# Define the chasing pattern
pattern = list(range(len(led_pins))) + list(range(len(led_pins) - 2, 0, -1))

while True:
    for idx in pattern:
        # Turn on the current LED
        leds[idx].on()
        time.sleep(0.1)  # Adjust the delay between LEDs if needed
        # Turn off the current LED
        leds[idx].off()
    time.sleep(0.5)  # Adjust the delay between the chase forwards and backwards
