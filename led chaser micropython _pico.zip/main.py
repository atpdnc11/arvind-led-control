import machine
import utime

# Set up the LED pins
led_pins = [2, 3, 4, 5, 6]  # adjust as needed
leds = [machine.Pin(pin, machine.Pin.OUT) for pin in led_pins]

# Chase the LEDs
i = 0
while True:
    for j in range(len(leds)):
        if j == i:
            leds[j].value(1)
        else:
            leds[j].value(0)
        utime.sleep(0.1)
    i = (i + 1) % len(leds)
