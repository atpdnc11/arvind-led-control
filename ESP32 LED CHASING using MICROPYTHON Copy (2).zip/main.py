/*********************

n this code, we use the machine.Pin class from the machine module to 
control the LED pins. We define the LED pins as outputs and create a 
list of Pin objects for each pin. The pattern list represents the order
 in which the LEDs will light up.

Inside the while loop, we iterate through the pattern list and turn on 
each LED for a short period using the on() method. Then, we turn off the
 LED using the off() method. The time.sleep() functions are used to introduce 
 delays between LED changes.

The pattern starts with the LEDs lighting up from the first pin to 
the last, and then reverses the order to light up from the second last 
pin to the second pin. This creates the chasing effect. The delay values 
can be adjusted to modify the speed of the chase and the time between 
forward and backward movements.

Note: Make sure you have MicroPython firmware installed on
 your ESP32 and the required libraries are available.

 by arvind patil 31/05/23


*********************************/

import time
from machine import Pin

# Define the GPIO pins for the LEDs
led_pins = [25, 26, 27, 14, 12, 13, 15, 2, 4,18 ]

# Initialize the LED pins as output pins
leds = [Pin(pin, Pin.OUT) for pin in led_pins]

# Define the pattern for the LED chase
pattern = [1, 2, 4, 8, 16, 8, 4, 2]

# Define the pattern for the LED chase
pattern = [1, 2, 4, 8, 18, 8, 4, 2]



# Infinite loop to repeat the LED chase
while True:
    # Loop through the pattern forwards
    for i in range(len(pattern)):
        for j in range(len(leds)):
            if pattern[i] & (1 << j):
                leds[j].on()
            else:
                leds[j].off()
        time.sleep(0.3)
    
    # Loop through the pattern backwards
    for i in range(len(pattern)-2, 0, -1):
        for j in range(len(leds)):
            if pattern[i] & (1 << j):
                leds[j].on()
            else:
                leds[j].off()
        time.sleep(0.3)
