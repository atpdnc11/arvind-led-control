import time
from machine import Pin

# Set the GPIO pins for the LEDs
led_pins = [14, 27, 26, 25, 33, 32, 15, 12, 13, 2]

# Set the LED chase pattern
chase_pattern = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9, 8, 7, 6, 5, 4, 3, 2]

# Initialize the LED pins as output pins
leds = [Pin(pin_num, Pin.OUT) for pin_num in led_pins]

# Chase the LEDs back and forth indefinitely
while True:
    for i in range(len(chase_pattern)):
        leds[chase_pattern[i]-1].on()
        time.sleep(0.3)
        leds[chase_pattern[i]-1].off()
    for i in range(len(chase_pattern)-2, 0, -1):
        leds[chase_pattern[i]-1].on()
        time.sleep(0.3)
        leds[chase_pattern[i]-1].off()
